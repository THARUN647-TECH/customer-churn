# Hiver SDE Intern Assignment — AI Support Agent

## Project goal
Build a small, reproducible AI support agent that:
1. classifies a customer message into an intent,
2. retrieves similar historical support cases,
3. drafts a grounded reply,
4. decides whether to auto-handle or escalate.

The project is based on the **Customer Support on Twitter** dataset and focuses on **SpotifyCares**, following the workflow in the supplied Hiver SDE Intern Assignment brief.

## Current dataset findings
The supplied notebook successfully loaded **2,811,774 tweets**. SpotifyCares filtering produced **74,618 tweets**, including **31,353 inbound customer tweets** and **43,265 outbound SpotifyCares tweets**. The notebook's reconstruction run produced **29,935 conversations** and **18,553 initial customer messages**.

These numbers are taken from the supplied notebook output. The ZIP does not fabricate classifier metrics; evaluation metrics are generated only after human labels are supplied.

## Folder structure
```text
hiver-support-agent/
├── data/
│   ├── raw/
│   │   └── README.txt
│   ├── processed/
│   └── golden/
│       └── golden_set_example.csv
├── evaluation/
│   ├── evaluate_intent.py
│   ├── evaluate_replies.py
│   └── llm_judge.py
├── models/
├── notebooks/
│   └── Spotify_original.ipynb
├── outputs/
├── scripts/
│   ├── prepare_data.py
│   └── run_agent.py
├── src/
│   ├── data_loader.py
│   ├── preprocessing.py
│   ├── conversation_builder.py
│   ├── intent_classifier.py
│   ├── retriever.py
│   ├── response_generator.py
│   ├── escalation.py
│   ├── pipeline.py
│   ├── create_golden_template.py
│   └── build_training_data.py
├── tests/
├── main.py
├── requirements.txt
└── REPORT.pdf
```

## Setup
Use Python 3.10+.

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
```

## Dataset
Download the Kaggle dataset used in the supplied notebook and place `twcs.csv` at:

```text
data/raw/twcs.csv
```

The original dataset download is intentionally not bundled because it is approximately 169 MB.

## Step 1 — Prepare SpotifyCares data

```bash
python scripts/prepare_data.py
```

This creates:
- `data/processed/spotify_filtered.csv`
- `data/processed/conversations.json`
- `data/processed/initial_customer_messages.csv`
- `outputs/dataset_stats.json`

## Step 2 — Create the 150–250 example Golden Set

The assignment asks for a human-labelled golden set. Create a 200-row labelling template:

```bash
python -m src.create_golden_template --n 200
```

Open:

```text
data/golden/golden_set.csv
```

and manually fill:
- `intent`
- `expected_handling`
- `expected_reply`

### Recommended 10 intents
1. Account Issues
2. Billing/Subscription
3. Refund
4. Login/Password
5. Technical Issue
6. Playback/Offline Issue
7. Content/Playlist Issue
8. Feature Request
9. Availability/Region
10. General Inquiry/Feedback

These are a project taxonomy proposal and should be checked against the actual sampled messages before final submission.

## Step 3 — Build training data

```bash
python -m src.build_training_data
```

This creates:

```text
data/processed/training_data.csv
```

## Step 4 — Train and evaluate the intent model

```bash
python -m evaluation.evaluate_intent
```

Model:
- TF-IDF word n-grams (1–2)
- Logistic Regression
- class-balanced training
- 80/20 stratified split

Results are written to:

```text
outputs/intent_metrics.json
models/intent_classifier.joblib
```

## Step 5 — Run the complete support agent

```bash
python main.py
```

The pipeline is:

```text
Customer message
      ↓
Text preprocessing
      ↓
Intent classifier
      ↓
Historical TF-IDF + cosine retrieval
      ↓
Grounded historical reply / intent template
      ↓
Confidence + evidence check
      ↓
AUTO-HANDLE or ESCALATE
```

## Step 6 — Interactive mode

```bash
python -m scripts.run_agent
```

Type a customer message. Type `exit` to stop.

## Testing

```bash
python -m tests.test_pipeline
```

## Important evaluation note
The assignment requires **150–250 human-labelled examples**. The repository therefore provides a template generator rather than inventing labels for the 18,553 customer messages. Do not report accuracy, F1, or confusion-matrix numbers until the labelled set has actually been created and evaluated.

The included `llm_judge.py` is a lightweight offline quality checker, not a claim of LLM-based evaluation. If an API-based LLM judge is later added, document the model, prompt, cost, and date.

## Report
See `REPORT.pdf` for a concise 3–6 page project report covering objective, dataset analysis, system design, intent taxonomy, evaluation plan, limitations, and next steps.
