DATASET SETUP
=============
The full twcs.csv dataset is intentionally not included in this ZIP because the original download is about 169 MB.

Source dataset:
Kaggle - thoughtvector/customer-support-on-twitter
File required:
data/raw/twcs.csv

Expected columns:
tweet_id, author_id, inbound, created_at, text, response_tweet_id, in_response_to_tweet_id

After placing twcs.csv in data/raw/, run:
python scripts/prepare_data.py
