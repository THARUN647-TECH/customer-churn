import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class HistoricalRetriever:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True)
        self.documents = []
        self.responses = []
        self.matrix = None

    def fit(self, customer_messages, responses):
        self.documents = list(customer_messages)
        self.responses = list(responses)
        if not self.documents:
            raise ValueError("No historical customer messages supplied.")
        self.matrix = self.vectorizer.fit_transform(self.documents)
        return self

    def search(self, query, top_k=3):
        if self.matrix is None:
            raise RuntimeError("Fit the retriever before searching.")
        q = self.vectorizer.transform([query])
        scores = cosine_similarity(q, self.matrix)[0]
        indices = np.argsort(scores)[::-1][:top_k]
        return [
            {
                "customer_message": self.documents[i],
                "response": self.responses[i],
                "similarity": float(scores[i]),
            }
            for i in indices
        ]
