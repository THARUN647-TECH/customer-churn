from pathlib import Path
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report


class IntentClassifier:
    def __init__(self):
        self.model = Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_df=0.98, sublinear_tf=True)),
            ("classifier", LogisticRegression(max_iter=1500, class_weight="balanced")),
        ])
        self.is_trained = False

    def train(self, texts, labels):
        self.model.fit(texts, labels)
        self.is_trained = True
        return self

    def predict(self, text):
        if not self.is_trained:
            raise RuntimeError("Train or load the classifier before prediction.")
        label = self.model.predict([text])[0]
        confidence = float(self.model.predict_proba([text]).max())
        return label, confidence

    def evaluate(self, texts, labels):
        predictions = self.model.predict(texts)
        print(classification_report(labels, predictions, zero_division=0))
        return predictions

    def save(self, path="models/intent_classifier.joblib"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self.model, path)

    def load(self, path="models/intent_classifier.joblib"):
        self.model = joblib.load(path)
        self.is_trained = True
        return self
