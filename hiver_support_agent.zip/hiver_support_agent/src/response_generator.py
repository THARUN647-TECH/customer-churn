class ResponseGenerator:
    """Template fallback plus strong historical evidence when available."""

    templates = {
        "Account Issues": "We can help with your account issue. Please share the relevant account details privately so we can check it securely.",
        "Billing/Subscription": "We can help check your subscription or payment issue. Please share the relevant account details privately so we can look into it.",
        "Refund": "We can help review your refund request. Please share the transaction or account details privately so we can check it.",
        "Login/Password": "We can help with your login issue. Please use the account recovery option and let us know if you still cannot access the account.",
        "Technical Issue": "Sorry you are having trouble with Spotify. Please tell us your device and Spotify app version so we can investigate.",
        "Playback/Offline Issue": "Sorry about the playback or offline issue. Please share your device and app version and we can help troubleshoot it.",
        "Content/Playlist Issue": "Thanks for reporting the content or playlist issue. Please provide the song, artist, or playlist details so we can investigate.",
        "Feature Request": "Thanks for the feature suggestion. We appreciate the feedback and will pass it along to the appropriate team.",
        "Availability/Region": "Spotify availability and offers can depend on the country or region. Please tell us your country so we can provide the relevant information.",
        "General Inquiry/Feedback": "Thanks for contacting SpotifyCares. Please provide a little more information about your question so we can help.",
    }

    def generate(self, message, intent, historical_cases):
        if historical_cases and historical_cases[0]["similarity"] >= 0.65:
            return historical_cases[0]["response"]
        return self.templates.get(intent, self.templates["General Inquiry/Feedback"])
