import argparse
from pathlib import Path
import pandas as pd


def build(golden_csv, output_csv):
    g = pd.read_csv(golden_csv)
    required = {"processed_text", "intent", "expected_reply"}
    missing = required - set(g.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    g = g.dropna(subset=["processed_text", "intent"])
    g = g[g["intent"].astype(str).str.strip() != ""]
    if len(g) < 20:
        raise ValueError("At least 20 labelled examples are recommended before training.")
    out = g[["processed_text", "intent", "expected_reply"]].rename(columns={"expected_reply": "response"})
    Path(output_csv).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_csv, index=False)
    print(f"Training rows: {len(out)}")
    print(out["intent"].value_counts())


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--golden", default="data/golden/golden_set.csv")
    p.add_argument("--output", default="data/processed/training_data.csv")
    args = p.parse_args()
    build(args.golden, args.output)
