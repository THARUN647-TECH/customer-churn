import html
import re
import pandas as pd


def preprocess_text(text):
    if pd.isna(text):
        return ""
    text = html.unescape(str(text)).lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"@\w+", " ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def preprocess_dataframe(df, text_column="text"):
    out = df.copy()
    out["processed_text"] = out[text_column].map(preprocess_text)
    return out
