from pathlib import Path
import pandas as pd


def load_dataset(path):
    """Load the Customer Support on Twitter CSV."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")
    return pd.read_csv(path)


def select_brand(df, brand="SpotifyCares"):
    """Select brand replies and customer tweets directed to the brand."""
    mask = (
        (df["author_id"].astype(str) == brand)
        | df["text"].astype(str).str.contains(
            rf"@{brand}\b", case=False, na=False
        )
    )
    return df.loc[mask].copy()


def dataset_stats(df):
    """Return basic statistics used in the assignment."""
    return {
        "rows": int(len(df)),
        "columns": int(df.shape[1]),
        "inbound_customer": int(df["inbound"].eq(True).sum()),
        "outbound_brand": int(df["inbound"].eq(False).sum()),
        "missing_values": int(df.isna().sum().sum()),
        "duplicate_tweet_ids": int(df["tweet_id"].duplicated().sum()),
    }
