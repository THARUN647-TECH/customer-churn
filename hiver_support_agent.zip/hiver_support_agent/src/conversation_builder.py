from collections import defaultdict, deque
import pandas as pd


def reconstruct_conversations(df):
    """Reconstruct parent/child Twitter threads using IDs present in the filtered dataset.

    A tweet is connected to its parent only when that parent exists in the filtered dataset.
    Threads are then traversed from roots and sorted by creation time.
    """
    d = df.copy()
    d["tweet_id"] = pd.to_numeric(d["tweet_id"], errors="coerce")
    d["in_response_to_tweet_id"] = pd.to_numeric(
        d["in_response_to_tweet_id"], errors="coerce"
    )
    d["created_at_dt"] = pd.to_datetime(
        d["created_at"], format="%a %b %d %H:%M:%S +0000 %Y", errors="coerce"
    )
    d = d.dropna(subset=["tweet_id"]).drop_duplicates("tweet_id")
    d["tweet_id"] = d["tweet_id"].astype(int)

    tweet_map = d.set_index("tweet_id").to_dict("index")
    children = defaultdict(list)

    for tweet_id, info in tweet_map.items():
        parent = info.get("in_response_to_tweet_id")
        if pd.notna(parent) and int(parent) in tweet_map:
            children[int(parent)].append(tweet_id)

    roots = []
    for tweet_id, info in tweet_map.items():
        parent = info.get("in_response_to_tweet_id")
        if pd.isna(parent) or int(parent) not in tweet_map:
            roots.append(tweet_id)

    conversations = []
    processed = set()

    for root in roots:
        if root in processed:
            continue
        queue = deque([root])
        ids = []
        while queue:
            current = queue.popleft()
            if current in processed or current not in tweet_map:
                continue
            processed.add(current)
            ids.append(current)
            queue.extend(x for x in children.get(current, []) if x not in processed)

        if ids:
            conv = d[d["tweet_id"].isin(ids)].sort_values("created_at_dt")
            conversations.append(
                conv[["tweet_id", "author_id", "text", "inbound", "created_at", "in_response_to_tweet_id"]]
                .to_dict("records")
            )

    return conversations


def extract_initial_customer_messages(conversations):
    """Take the first inbound tweet from each reconstructed conversation."""
    from .preprocessing import preprocess_text
    records = []
    for idx, conv in enumerate(conversations):
        for turn in conv:
            if bool(turn.get("inbound")):
                records.append(
                    {
                        "conversation_id": conv[0]["tweet_id"],
                        "tweet_id": turn["tweet_id"],
                        "original_text": turn["text"],
                        "processed_text": preprocess_text(turn["text"]),
                    }
                )
                break
    return pd.DataFrame(records)
