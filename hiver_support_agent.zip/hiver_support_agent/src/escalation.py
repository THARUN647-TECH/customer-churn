class EscalationEngine:
    def __init__(self, confidence_threshold=0.70, evidence_threshold=0.55):
        self.confidence_threshold = confidence_threshold
        self.evidence_threshold = evidence_threshold

    def decide(self, confidence, historical_cases, intent):
        evidence = historical_cases[0]["similarity"] if historical_cases else 0.0
        if confidence >= self.confidence_threshold and evidence >= self.evidence_threshold:
            return {
                "decision": "AUTO-HANDLE",
                "reason": "Intent confidence and historical evidence meet the configured thresholds.",
            }
        return {
            "decision": "ESCALATE",
            "reason": "Intent confidence or historical evidence is below the configured threshold.",
        }
