from .preprocessing import preprocess_text
from .response_generator import ResponseGenerator
from .escalation import EscalationEngine


class SupportAgent:
    def __init__(self, classifier, retriever, escalation=None):
        self.classifier = classifier
        self.retriever = retriever
        self.response_generator = ResponseGenerator()
        self.escalation = escalation or EscalationEngine()

    def process(self, message, top_k=3):
        clean = preprocess_text(message)
        intent, confidence = self.classifier.predict(clean)
        cases = self.retriever.search(clean, top_k=top_k)
        reply = self.response_generator.generate(clean, intent, cases)
        decision = self.escalation.decide(confidence, cases, intent)
        return {
            "message": message,
            "intent": intent,
            "confidence": round(confidence, 4),
            "historical_cases": cases,
            "reply": reply,
            "decision": decision["decision"],
            "reason": decision["reason"],
        }
