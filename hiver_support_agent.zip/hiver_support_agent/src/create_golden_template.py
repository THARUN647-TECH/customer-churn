import argparse
from pathlib import Path
import pandas as pd

INTENTS = [
    "Account Issues",
    "Billing/Subscription",
    "Refund",
    "Login/Password",
    "Technical Issue",
    "Playback/Offline Issue",
    "Content/Playlist Issue",
    "Feature Request",
    "Availability/Region",
    "General Inquiry/Feedback",
]


def create_template(input_csv, output_csv, n=200, seed=42):
    df = pd.read_csv(input_csv)
    required = {"conversation_id", "tweet_id", "original_text", "processed_text"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    n = min(n, len(df))
    sample = df.sample(n=n, random_state=seed).copy()
    out = pd.DataFrame({
        "conversation_id": sample["conversation_id"].values,
        "tweet_id": sample["tweet_id"].values,
        "message": sample["original_text"].values,
        "processed_text": sample["processed_text"].values,
        "intent": "",
        "expected_handling": "",
        "expected_reply": "",
    })
    Path(output_csv).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_csv, index=False)
    print(f"Created {len(out)} rows: {output_csv}")
    print("Allowed intents:")
    for x in INTENTS:
        print(" -", x)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--input", default="data/processed/initial_customer_messages.csv")
    p.add_argument("--output", default="data/golden/golden_set.csv")
    p.add_argument("--n", type=int, default=200)
    args = p.parse_args()
    create_template(args.input, args.output, args.n)
