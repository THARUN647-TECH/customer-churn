import pandas as pd


def score_reply(generated_reply, historical_cases):
    best_similarity = historical_cases[0]["similarity"] if historical_cases else 0.0
    return {
        "relevance": int(best_similarity >= 0.50),
        "grounded": int(best_similarity >= 0.65),
        "non_empty": int(bool(generated_reply and len(generated_reply.strip()) > 20)),
    }


def summarize(results):
    df = pd.DataFrame(results)
    if df.empty:
        return {}
    return df.mean(numeric_only=True).to_dict()
