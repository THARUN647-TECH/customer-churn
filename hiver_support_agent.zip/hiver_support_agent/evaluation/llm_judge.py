def judge_reply(customer_message, reply, intent):
    """Lightweight deterministic judge for local/offline evaluation.

    This is intentionally not presented as an LLM judge. It checks basic
    properties so the repository remains runnable without an API key.
    """
    checks = {
        "has_reply": bool(reply and reply.strip()),
        "reasonable_length": 20 <= len(reply or "") <= 500,
        "has_intent": bool(intent),
        "has_customer_context": bool(customer_message),
    }
    return {"checks": checks, "score": sum(checks.values()) / len(checks)}
