import argparse
import json
from pathlib import Path
import pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from src.intent_classifier import IntentClassifier


def main(path):
    df = pd.read_csv(path).dropna(subset=["processed_text", "intent"])
    X_train, X_test, y_train, y_test = train_test_split(
        df["processed_text"], df["intent"], test_size=0.20, random_state=42, stratify=df["intent"]
    )
    clf = IntentClassifier().train(X_train, y_train)
    pred = clf.model.predict(X_test)
    p, r, f1, _ = precision_recall_fscore_support(y_test, pred, average="weighted", zero_division=0)
    result = {
        "accuracy": float(accuracy_score(y_test, pred)),
        "precision_weighted": float(p),
        "recall_weighted": float(r),
        "f1_weighted": float(f1),
        "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
    }
    print(json.dumps(result, indent=2))
    print(classification_report(y_test, pred, zero_division=0))
    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/intent_metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    clf.save()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/processed/training_data.csv")
    args = p.parse_args()
    main(args.data)
