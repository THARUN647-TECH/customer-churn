from src.preprocessing import preprocess_text


def test_preprocessing():
    x = preprocess_text("@SpotifyCares I cannot login! https://spotify.com")
    assert "spotifycares" not in x
    assert "https" not in x
    assert "cannot login" in x


def test_empty():
    assert preprocess_text("") == ""


if __name__ == "__main__":
    test_preprocessing()
    test_empty()
    print("All tests passed")
