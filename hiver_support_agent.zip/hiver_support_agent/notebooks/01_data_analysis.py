"""Reference script corresponding to the first analysis notebook."""
import pandas as pd
from src.data_loader import select_brand, dataset_stats
from src.conversation_builder import reconstruct_conversations, extract_initial_customer_messages

DATA = "data/raw/twcs.csv"

df = pd.read_csv(DATA)
spotify_df = select_brand(df, "SpotifyCares")
print(dataset_stats(spotify_df))
conversations = reconstruct_conversations(spotify_df)
print("Conversations:", len(conversations))
initial = extract_initial_customer_messages(conversations)
initial.to_csv("data/processed/initial_customer_messages.csv", index=False)
print("Initial customer messages:", len(initial))
