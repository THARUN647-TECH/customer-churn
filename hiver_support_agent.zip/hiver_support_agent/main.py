import pandas as pd
from src.intent_classifier import IntentClassifier
from src.retriever import HistoricalRetriever
from src.pipeline import SupportAgent


def build_agent(path="data/processed/training_data.csv"):
    df = pd.read_csv(path).dropna(subset=["processed_text", "intent", "response"])
    classifier = IntentClassifier().train(df["processed_text"], df["intent"])
    retriever = HistoricalRetriever().fit(df["processed_text"], df["response"])
    return SupportAgent(classifier, retriever)


def main():
    agent = build_agent()
    messages = [
        "I cannot login to my Spotify account",
        "I was charged twice for premium",
        "Spotify keeps crashing on my phone",
        "I want a dislike button",
        "When will Spotify launch in my country?",
    ]
    for message in messages:
        result = agent.process(message)
        print("\n" + "=" * 70)
        print("Customer:", result["message"])
        print("Intent:", result["intent"])
        print("Confidence:", result["confidence"])
        print("Decision:", result["decision"])
        print("Reason:", result["reason"])
        print("Reply:", result["reply"])
        print("Top historical similarity:", round(result["historical_cases"][0]["similarity"], 3))


if __name__ == "__main__":
    main()
