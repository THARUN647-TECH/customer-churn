from pathlib import Path
import json
import pandas as pd
from src.data_loader import select_brand, dataset_stats
from src.conversation_builder import reconstruct_conversations, extract_initial_customer_messages


def main():
    raw = Path("data/raw/twcs.csv")
    if not raw.exists():
        raise FileNotFoundError("Place twcs.csv in data/raw/ first.")
    df = pd.read_csv(raw)
    spotify = select_brand(df, "SpotifyCares")
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    spotify.to_csv("data/processed/spotify_filtered.csv", index=False)
    stats = dataset_stats(spotify)
    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/dataset_stats.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    conversations = reconstruct_conversations(spotify)
    with open("data/processed/conversations.json", "w", encoding="utf-8") as f:
        json.dump(conversations, f, ensure_ascii=False)
    initial = extract_initial_customer_messages(conversations)
    initial.to_csv("data/processed/initial_customer_messages.csv", index=False)
    print("SpotifyCares rows:", len(spotify))
    print("Conversations:", len(conversations))
    print("Initial customer messages:", len(initial))
    print("Stats:", stats)


if __name__ == "__main__":
    main()
