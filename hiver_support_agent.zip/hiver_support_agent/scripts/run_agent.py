from main import build_agent


def main():
    agent = build_agent()
    print("Hiver support agent ready. Type 'exit' to stop.")
    while True:
        message = input("\nCustomer: ").strip()
        if message.lower() == "exit":
            break
        result = agent.process(message)
        print("Intent:", result["intent"])
        print("Confidence:", result["confidence"])
        print("Decision:", result["decision"])
        print("Reply:", result["reply"])
        print("Reason:", result["reason"])


if __name__ == "__main__":
    main()
